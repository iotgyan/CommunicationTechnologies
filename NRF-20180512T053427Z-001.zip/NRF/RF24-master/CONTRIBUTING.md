Try your best to follow the NASA C style http://homepages.inf.ed.ac.uk/dts/pm/Papers/nasa-c-style.pdf
